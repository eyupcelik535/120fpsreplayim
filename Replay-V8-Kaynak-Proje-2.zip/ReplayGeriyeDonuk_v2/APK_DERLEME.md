# APK elde etme (Android Studio kurmadan)

Bu kaynak proje için GitHub Actions iş akışı eklendi: `.github/workflows/build-apk.yml`.

1. ZIP'i bilgisayarda aç. GitHub üzerinde yeni bir depo oluştur.
2. ZIP'in içindeki dosya ve klasörleri (gizli `.github` klasörü dahil) depoya **ayrı ayrı** yükle; ZIP'i tek dosya olarak yükleme.
3. GitHub deposundaki **Actions → Android APK Olustur → Run workflow** sayfasından derlemeyi başlat.
4. Başarılı tamamlanan çalışmanın **Artifacts** bölümünden `ReplayGeriyeDonuk-APK` dosyasını indir. Arşivin içinde `app-debug.apk` bulunur.

Alternatif: Android Studio'da proje klasörünü aç ve **Build → Build APK(s)** seç.

**Durum:** APK bu ortamda derlenmemiş ve cihazda test edilmemiştir. Android Gradle Plugin 8.7.3 / Gradle 8.9 / SDK 35 / JDK 17 hedeflenmiştir. Derleme veya telefon testi sırasında değişiklik gerekebilir.

**Güvenlik:** Bu APK debug anahtarıyla imzalanır ve uygulama sadece izin verdiğin zaman ekranını yakalar. Tanımadığın kişilere ekran videolarını verme.
