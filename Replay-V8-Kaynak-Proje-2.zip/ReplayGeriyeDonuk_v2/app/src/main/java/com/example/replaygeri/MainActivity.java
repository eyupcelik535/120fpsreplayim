package com.example.replaygeri;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 100;
    private static final int REQUEST_AUDIO = 101;
    private static final int REQUEST_NOTIFICATIONS = 102;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private TextView statusText;
    private Spinner duration, quality, fps, bitrate;
    private Switch internalAudioSwitch, micAudioSwitch;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        statusText = findViewById(R.id.statusText);
        duration = findViewById(R.id.durationSpinner);
        quality = findViewById(R.id.qualitySpinner);
        fps = findViewById(R.id.fpsSpinner);
        bitrate = findViewById(R.id.bitrateSpinner);
        internalAudioSwitch = findViewById(R.id.internalAudioSwitch);
        micAudioSwitch = findViewById(R.id.micAudioSwitch);
        setupSpinner(duration, new String[]{"15 saniye", "30 saniye", "60 saniye"}, new int[]{15,30,60}, "duration", 30);
        setupSpinner(quality, new String[]{"720p", "1080p"}, new int[]{720,1080}, "quality", 1080);
        setupSpinner(fps, new String[]{"30 FPS", "60 FPS", "120 FPS"}, new int[]{30,60,120}, "fps", 120);
        setupSpinner(bitrate, new String[]{"6 Mbps", "12 Mbps", "20 Mbps", "40 Mbps", "50 Mbps", "75 Mbps", "100 Mbps"},
                new int[]{6,12,20,40,50,75,100}, "mbps", 50);

        internalAudioSwitch.setChecked(prefs.getBoolean("capture_playback_audio", true));
        micAudioSwitch.setChecked(prefs.getBoolean("capture_mic_audio", false));
        internalAudioSwitch.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("capture_playback_audio", checked).apply());
        micAudioSwitch.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("capture_mic_audio", checked).apply());

        findViewById(R.id.startButton).setOnClickListener(v -> startRequested());
        findViewById(R.id.saveButton).setOnClickListener(v -> {
            if (!ReplayService.active) { toast("Önce tampon kaydı başlat."); return; }
            Intent i = new Intent(this, ReplayService.class).setAction(ReplayService.ACTION_SAVE);
            i.putExtra("seconds", prefs.getInt("duration", 30));
            startService(i);
        });
        findViewById(R.id.stopButton).setOnClickListener(v -> {
            if (ReplayService.active) startService(new Intent(this, ReplayService.class).setAction(ReplayService.ACTION_STOP));
            else toast("Aktif kayıt yok.");
            handler.postDelayed(this::refreshStatus, 400);
        });
        findViewById(R.id.overlayButton).setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                toast("Açılan Android ekranından 'Diğer uygulamaların üzerinde göster'e izin ver.");
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else if (ReplayService.active) {
                startService(new Intent(this, ReplayService.class).setAction(ReplayService.ACTION_OVERLAY));
                toast("Oyun üstü düğmesi açıldı.");
            } else toast("İzin hazır. Kaydı başlatınca düğme görünecek.");
        });
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private void setupSpinner(Spinner spinner, String[] labels, int[] values, String key, int fallback) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        int selected = prefs.getInt(key, fallback);
        for (int i = 0; i < values.length; i++) if (selected == values[i]) spinner.setSelection(i);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                prefs.edit().putInt(key, values[position]).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    private boolean wantsAnyAudio() {
        return prefs.getBoolean("capture_playback_audio", true) || prefs.getBoolean("capture_mic_audio", false);
    }

    private void startRequested() {
        if (ReplayService.active) {
            toast("Tampon zaten çalışıyor. Ayar değişiklikleri için durdurup yeniden başlat.");
            return;
        }
        if (wantsAnyAudio() && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        askScreenPermission();
    }

    private void askScreenPermission() {
        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
        } catch (Exception e) { toast("Ekran izni açılamadı: " + e.getMessage()); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_AUDIO) {
            if (results.length == 0 || results[0] != PackageManager.PERMISSION_GRANTED) {
                prefs.edit()
                        .putBoolean("capture_playback_audio", false)
                        .putBoolean("capture_mic_audio", false)
                        .apply();
                internalAudioSwitch.setChecked(false);
                micAudioSwitch.setChecked(false);
                toast("Mikrofon/ses izni verilmedi; yalnızca görüntü kaydedilecek.");
            }
            askScreenPermission();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent intent = new Intent(this, ReplayService.class);
            intent.setAction(ReplayService.ACTION_START);
            intent.putExtra("resultCode", resultCode);
            intent.putExtra("resultData", data);
            try { startForegroundService(intent); }
            catch (Exception e) { toast("Servis başlatılamadı: " + e.getMessage()); }
            handler.postDelayed(this::refreshStatus, 1400);
        } else if (requestCode == REQUEST_CAPTURE) toast("Ekran paylaşım izni verilmedi.");
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
        handler.postDelayed(statusTicker, 1000);
        if (ReplayService.active && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, ReplayService.class).setAction(ReplayService.ACTION_OVERLAY));
        }
    }

    private final Runnable statusTicker = new Runnable() {
        @Override public void run() {
            refreshStatus();
            handler.postDelayed(this, 1500);
        }
    };

    @Override protected void onPause() {
        handler.removeCallbacks(statusTicker);
        super.onPause();
    }

    private String selectedAudioLabel() {
        boolean playback = prefs.getBoolean("capture_playback_audio", true);
        boolean mic = prefs.getBoolean("capture_mic_audio", false);
        if (playback && mic) return "Cihaz sesi + mikrofon";
        if (playback) return "Sadece cihaz sesi";
        if (mic) return "Sadece mikrofon";
        return "Ses kapalı";
    }

    private void refreshStatus() {
        if (statusText == null) return;
        statusText.setText(ReplayService.active
                ? "● AKTİF — Geçmiş görüntüler geçici disk tamponunda tutuluyor.\nSes modu: " + selectedAudioLabel()
                    + "\nAktif kodlayıcı: " + prefs.getString("active_video", "Belirleniyor")
                    + "\nKaydet tuşuyla son " + prefs.getInt("duration", 30) + " saniyeyi galeriye aktar."
                : "● PASİF — Ekran yakalama başlamadı.\nSeçili ses modu: " + selectedAudioLabel());
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
