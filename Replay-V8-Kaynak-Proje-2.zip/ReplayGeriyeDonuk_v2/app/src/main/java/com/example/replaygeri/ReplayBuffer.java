package com.example.replaygeri;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaFormat;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * Rolling, disk-backed cache of encoded VIDEO samples. Video payload is never retained
 * in the Java heap. Audio is small enough to keep in RAM (~1 MB/minute at 128 kbps).
 * Files are temporary, private to the app and removed when no longer referenced.
 */
final class ReplayBuffer {
    static final long KEEP_US = 70_000_000L;
    static final long MAX_VIDEO_BYTES = 1_073_741_824L; // 1 GiB of video payload
    private static final long SEGMENT_LIMIT = 32L * 1024L * 1024L;

    static final class FileSegment {
        final File file;
        int liveSamples;
        int pins;
        boolean active;
        long written;
        FileSegment(File file) { this.file = file; }
    }

    static final class EncodedSample {
        final byte[] data; // non-null only for audio and incoming video samples
        final FileSegment segment; // non-null for retained video samples
        final long offset;
        final int size;
        final long ptsUs;
        final int flags;

        EncodedSample(byte[] data, long ptsUs, int flags) {
            this.data = data;
            this.segment = null;
            this.offset = 0;
            this.size = data.length;
            this.ptsUs = ptsUs;
            this.flags = flags;
        }

        EncodedSample(FileSegment segment, long offset, int size, long ptsUs, int flags) {
            this.data = null;
            this.segment = segment;
            this.offset = offset;
            this.size = size;
            this.ptsUs = ptsUs;
            this.flags = flags;
        }
        boolean isKeyFrame() { return (flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0; }
    }

    static final class Snapshot implements AutoCloseable {
        final List<EncodedSample> video;
        final List<EncodedSample> audio;
        final MediaFormat videoFormat;
        final MediaFormat audioFormat;
        final long basePtsUs;
        private final ReplayBuffer owner;
        private final Set<FileSegment> pinned;
        private boolean closed;

        Snapshot(ReplayBuffer owner, List<EncodedSample> video, List<EncodedSample> audio,
                 MediaFormat videoFormat, MediaFormat audioFormat,
                 long basePtsUs, Set<FileSegment> pinned) {
            this.owner = owner;
            this.video = video;
            this.audio = audio;
            this.videoFormat = videoFormat;
            this.audioFormat = audioFormat;
            this.basePtsUs = basePtsUs;
            this.pinned = pinned;
        }

        @Override public void close() {
            synchronized (owner) {
                if (closed) return;
                closed = true;
                for (FileSegment segment : pinned) {
                    segment.pins--;
                    owner.deleteIfUnused(segment);
                }
            }
        }
    }

    private final File cacheDir;
    private final LinkedList<EncodedSample> video = new LinkedList<>();
    private final LinkedList<EncodedSample> audio = new LinkedList<>();
    private long videoBytes;
    private long latestVideoUs = -1;
    private MediaFormat videoFormat;
    private MediaFormat audioFormat;
    private int nextSegmentId;
    private FileSegment current;
    private RandomAccessFile writer;
    private IOException failure;

    ReplayBuffer(Context context) {
        cacheDir = new File(context.getCacheDir(), "replay_v8_video_cache");
        if (!cacheDir.exists() && !cacheDir.mkdirs()) {
            failure = new IOException("Video cache directory could not be created");
        }
        // Previous process cannot hold live snapshots, so its private cache is stale.
        File[] stale = cacheDir.listFiles();
        if (stale != null) {
            for (File f : stale) {
                if (f.isFile() && f.getName().startsWith("segment_")) f.delete();
            }
        }
    }

    synchronized void setVideoFormat(MediaFormat value) { videoFormat = value; }
    synchronized void setAudioFormat(MediaFormat value) { audioFormat = value; }
    synchronized String getFailure() { return failure == null ? null : failure.getMessage(); }

    synchronized void reportFailure(Exception error) {
        if (failure == null) failure = new IOException(error.getMessage(), error);
    }

    synchronized void appendVideo(EncodedSample sample) throws IOException {
        if (failure != null) throw failure;
        if (sample.data == null || sample.size <= 0) return;
        if (current == null || current.written + sample.size > SEGMENT_LIMIT) rotate();
        long offset = current.written;
        try {
            writer.write(sample.data);
        } catch (IOException ex) {
            failure = ex;
            throw ex;
        }
        current.written += sample.size;
        current.liveSamples++;
        video.add(new EncodedSample(current, offset, sample.size, sample.ptsUs, sample.flags));
        videoBytes += sample.size;
        latestVideoUs = Math.max(latestVideoUs, sample.ptsUs);
        prune();
    }

    private void rotate() throws IOException {
        if (writer != null) {
            writer.close();
            writer = null;
        }
        if (current != null) {
            current.active = false;
            deleteIfUnused(current);
        }
        File file = new File(cacheDir, String.format(java.util.Locale.US,
                "segment_%06d.tmp", ++nextSegmentId));
        current = new FileSegment(file);
        current.active = true;
        try { writer = new RandomAccessFile(file, "rw"); }
        catch (IOException ex) {
            failure = ex;
            throw ex;
        }
    }

    synchronized void appendAudio(EncodedSample sample) {
        audio.add(sample);
        prune();
    }

    private void prune() {
        if (latestVideoUs < 0) return;
        long cutoff = latestVideoUs - KEEP_US;
        while (!video.isEmpty() &&
                (video.peekFirst().ptsUs < cutoff || videoBytes > MAX_VIDEO_BYTES)) {
            EncodedSample removed = video.removeFirst();
            videoBytes -= removed.size;
            removed.segment.liveSamples--;
            deleteIfUnused(removed.segment);
        }
        while (!audio.isEmpty() && audio.peekFirst().ptsUs < cutoff) audio.removeFirst();
    }

    private void deleteIfUnused(FileSegment segment) {
        if (!segment.active && segment.pins == 0 && segment.liveSamples == 0) {
            segment.file.delete();
        }
    }

    synchronized Snapshot snapshot(int requestedSeconds) {
        int seconds = Math.max(1, Math.min(60, requestedSeconds));
        if (failure != null || videoFormat == null || video.isEmpty()) return null;
        long start = latestVideoUs - seconds * 1_000_000L;
        // Never silently save a 38s clip when the user selected 60 seconds.
        if (latestVideoUs - video.peekFirst().ptsUs < seconds * 1_000_000L - 150_000L) {
            return null;
        }
        EncodedSample key = null;
        for (EncodedSample s : video) {
            if (s.ptsUs > start) break;
            if (s.isKeyFrame()) key = s;
        }
        if (key == null) return null; // wait until a keyframe preceding the target is available
        ArrayList<EncodedSample> selectedVideo = new ArrayList<>();
        ArrayList<EncodedSample> selectedAudio = new ArrayList<>();
        Set<FileSegment> pins = new HashSet<>();
        for (EncodedSample s : video) {
            if (s.ptsUs < key.ptsUs || s.ptsUs > latestVideoUs) continue;
            selectedVideo.add(s);
            pins.add(s.segment);
        }
        for (EncodedSample s : audio) {
            if (s.ptsUs >= key.ptsUs && s.ptsUs <= latestVideoUs) selectedAudio.add(s);
        }
        if (selectedVideo.size() < 3) return null;
        for (FileSegment segment : pins) segment.pins++;
        return new Snapshot(this, selectedVideo, selectedAudio, videoFormat,
                selectedAudio.isEmpty() ? null : audioFormat, key.ptsUs, pins);
    }

    synchronized void close() {
        try { if (writer != null) writer.close(); }
        catch (IOException ignored) { }
        writer = null;
        if (current != null) {
            current.active = false;
            current = null;
        }
        for (EncodedSample sample : video) {
            sample.segment.liveSamples--;
            deleteIfUnused(sample.segment);
        }
        video.clear();
        audio.clear();
        videoBytes = 0;
    }
}
