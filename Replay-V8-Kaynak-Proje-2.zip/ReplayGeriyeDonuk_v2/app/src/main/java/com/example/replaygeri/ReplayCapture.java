package com.example.replaygeri;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.media.MediaCodecList;
import java.io.RandomAccessFile;
import android.media.projection.MediaProjection;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.view.Surface;
import android.view.WindowManager;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.util.Log;
import java.util.concurrent.atomic.AtomicBoolean;

/** Hardware encodes screen to HEVC/AVC into a rolling disk-backed cache. */
final class ReplayCapture {
    interface SaveListener { void done(boolean success, String detail); }
    private static final int AUDIO_SAMPLE_RATE = 48_000;
    private static final int AUDIO_CHANNELS = 1;
    private static final int AUDIO_CHANNEL_MASK = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_BYTES_PER_SAMPLE = 2;

    private final Context app;
    private final ReplayBuffer ring;
    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private AudioRecord playbackRecord;
    private AudioRecord micRecord;
    private VirtualDisplay virtualDisplay;
    private Surface inputSurface;
    private Thread videoDrainThread, audioDrainThread, audioFeedThread;
    private volatile boolean running;
    private final AtomicBoolean saving = new AtomicBoolean(false);
    private long lastAudioPtsUs = -1L;

    ReplayCapture(Context context) {
        app = context.getApplicationContext();
        ring = new ReplayBuffer(app);
    }

    void start(MediaProjection projection, SharedPreferences p) throws Exception {
        int targetShortEdge = p.getInt("quality", 1080);
        int fps = p.getInt("fps", 120);
        int bitrate = p.getInt("mbps", 50) * 1_000_000;
        WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
        int screenWidth, screenHeight;
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect r = wm.getMaximumWindowMetrics().getBounds();
            screenWidth = r.width(); screenHeight = r.height();
        } else {
            Point size = new Point(); wm.getDefaultDisplay().getRealSize(size);
            screenWidth = size.x; screenHeight = size.y;
        }
        float scale = Math.min(1f, targetShortEdge / (float) Math.min(screenWidth, screenHeight));
        int width = Math.max(16, Math.round(screenWidth * scale) / 16 * 16);
        int height = Math.max(16, Math.round(screenHeight * scale) / 16 * 16);
        // Prefer 120 FPS first, then HEVC within the requested frame rate.
        // When a codec rejects 100 Mbps, use its highest advertised bitrate.
        videoEncoder = selectVideoEncoder(width, height, fps, bitrate, p);
        if (videoEncoder == null) {
            throw new IllegalStateException("Donanimsal 1080p video kodlayici baslatilamadi");
        }
        running = true;
        videoDrainThread = new Thread(() -> drain(videoEncoder, true), "Replay-VideoDrain");
        videoDrainThread.start();

        int density = app.getResources().getConfiguration().densityDpi;
        virtualDisplay = projection.createVirtualDisplay("ReplayBack",
                width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface, null, null);

        boolean capturePlayback = p.getBoolean("capture_playback_audio", true);
        boolean captureMic = p.getBoolean("capture_mic_audio", false);
        if ((capturePlayback || captureMic)
                && app.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try { startMixedAudio(projection, capturePlayback, captureMic); }
            catch (Exception audioUnavailable) { releaseAudioOnly(); }
        }
    }


    private MediaCodec selectVideoEncoder(int width, int height, int requestedFps,
                                          int requestedBitrate, SharedPreferences prefs) {
        final MediaCodecInfo[] codecs =
                new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos();
        final int[] frameRates = requestedFps > 60 ? new int[]{requestedFps, 60, 30}
                : requestedFps > 30 ? new int[]{requestedFps, 30} : new int[]{requestedFps};
        final String[] types = {MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_AVC};

        for (int fps : frameRates) {
            for (String type : types) {
                for (MediaCodecInfo codecInfo : codecs) {
                    if (!codecInfo.isEncoder() || !codecInfo.isHardwareAccelerated()) continue;
                    boolean supportsType = false;
                    for (String supported : codecInfo.getSupportedTypes()) {
                        if (supported.equalsIgnoreCase(type)) supportsType = true;
                    }
                    if (!supportsType) continue;
                    MediaCodecInfo.CodecCapabilities caps;
                    try { caps = codecInfo.getCapabilitiesForType(type); }
                    catch (Exception ignored) { continue; }
                    boolean surface = false;
                    for (int color : caps.colorFormats) {
                        if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface) {
                            surface = true;
                            break;
                        }
                    }
                    if (!surface) continue;
                    try {
                        if (!caps.getVideoCapabilities().areSizeAndRateSupported(width, height, fps)) {
                            continue;
                        }
                        int limit = caps.getVideoCapabilities().getBitrateRange().getUpper();
                        int bitrate = Math.min(requestedBitrate, limit);
                        if (bitrate <= 0) continue;
                        MediaFormat format = MediaFormat.createVideoFormat(type, width, height);
                        format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                        format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                        format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
                        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
                        if (caps.getEncoderCapabilities().isBitrateModeSupported(
                                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)) {
                            format.setInteger(MediaFormat.KEY_BITRATE_MODE,
                                    MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR);
                        }
                        // SDR content: BT.709; no fake 10-bit/HDR conversion.
                        format.setInteger(MediaFormat.KEY_COLOR_STANDARD,
                                MediaFormat.COLOR_STANDARD_BT709);
                        MediaCodec candidate = MediaCodec.createByCodecName(codecInfo.getName());
                        try {
                            candidate.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                            Surface surfaceInput = candidate.createInputSurface();
                            try {
                                candidate.start();
                            } catch (Exception ex) {
                                surfaceInput.release();
                                throw ex;
                            }
                            inputSurface = surfaceInput;
                            String codecLabel = type.equals(MediaFormat.MIMETYPE_VIDEO_HEVC) ? "H.265" : "H.264";
                            String description = codecLabel + " / " + fps + " FPS / "
                                    + (bitrate / 1_000_000) + " Mbps / " + width + "x" + height;
                            prefs.edit().putString("active_video", description).apply();
                            Log.i("ReplayV8", "Selected " + codecInfo.getName() + " : " + description);
                            return candidate;
                        } catch (Exception codecError) {
                            candidate.release();
                            Log.w("ReplayV8", "Failed to initialize " + codecInfo.getName(), codecError);
                        }
                    } catch (Exception unsupported) {
                        Log.w("ReplayV8", "Codec capabilities failure", unsupported);
                    }
                }
            }
        }
        return null;
    }

    private void startMixedAudio(MediaProjection projection, boolean capturePlayback, boolean captureMic) throws Exception {
        if (!capturePlayback && !captureMic) return;
        int min = AudioRecord.getMinBufferSize(AUDIO_SAMPLE_RATE, AUDIO_CHANNEL_MASK, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) throw new IllegalStateException("Audio input not supported");

        if (capturePlayback) playbackRecord = buildPlaybackRecord(projection, Math.max(min * 2, 16_384));
        if (captureMic) micRecord = buildMicRecord(Math.max(min * 2, 16_384));
        if (playbackRecord == null && micRecord == null) throw new IllegalStateException("No audio source available");

        MediaFormat audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,
                AUDIO_SAMPLE_RATE, AUDIO_CHANNELS);
        audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 128_000);
        audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        audioEncoder.start();

        if (playbackRecord != null) playbackRecord.startRecording();
        if (micRecord != null) micRecord.startRecording();

        final MediaCodec codec = audioEncoder;
        audioDrainThread = new Thread(() -> drain(codec, false), "Replay-AudioDrain");
        audioFeedThread = new Thread(this::feedMixedAudio, "Replay-AudioFeed");
        audioDrainThread.start();
        audioFeedThread.start();
    }

    private AudioRecord buildPlaybackRecord(MediaProjection projection, int bufferSize) {
        AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .build();
        AudioRecord record = new AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(config)
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(AUDIO_SAMPLE_RATE)
                        .setChannelMask(AUDIO_CHANNEL_MASK)
                        .build())
                .setBufferSizeInBytes(bufferSize)
                .build();
        return record.getState() == AudioRecord.STATE_INITIALIZED ? record : null;
    }

    private AudioRecord buildMicRecord(int bufferSize) {
        AudioRecord record = new AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(AUDIO_SAMPLE_RATE)
                        .setChannelMask(AUDIO_CHANNEL_MASK)
                        .build())
                .setBufferSizeInBytes(bufferSize)
                .build();
        return record.getState() == AudioRecord.STATE_INITIALIZED ? record : null;
    }

    private void feedMixedAudio() {
        final int targetBytes = 4096;
        byte[] playbackBytes = new byte[targetBytes];
        byte[] micBytes = new byte[targetBytes];
        byte[] mixedBytes = new byte[targetBytes];
        try {
            while (running) {
                int index = audioEncoder.dequeueInputBuffer(10_000);
                if (index < 0) continue;
                ByteBuffer input = audioEncoder.getInputBuffer(index);
                if (input == null) continue;
                input.clear();
                int limit = Math.min(targetBytes, input.remaining());
                if ((limit & 1) == 1) limit--;

                int playbackLength = readSource(playbackRecord, playbackBytes, limit);
                int micLength = readSource(micRecord, micBytes, limit);
                int outLength;

                if (playbackRecord != null && micRecord != null) {
                    outLength = Math.max(playbackLength, micLength);
                    if ((outLength & 1) == 1) outLength--;
                    mixPcm16(playbackBytes, playbackLength, micBytes, micLength, mixedBytes, outLength);
                } else if (playbackRecord != null) {
                    outLength = Math.max(0, playbackLength);
                    if (outLength > 0) System.arraycopy(playbackBytes, 0, mixedBytes, 0, outLength);
                } else {
                    outLength = Math.max(0, micLength);
                    if (outLength > 0) System.arraycopy(micBytes, 0, mixedBytes, 0, outLength);
                }

                if (outLength > 0) {
                    input.put(mixedBytes, 0, outLength);
                    long ptsUs = nextAudioPtsUs(outLength);
                    audioEncoder.queueInputBuffer(index, 0, outLength, ptsUs, 0);
                } else {
                    audioEncoder.queueInputBuffer(index, 0, 0, System.nanoTime() / 1000L, 0);
                }
            }
        } catch (IllegalStateException ignored) { }
    }

    private int readSource(AudioRecord record, byte[] buffer, int length) {
        if (record == null) return 0;
        try {
            int read = record.read(buffer, 0, length, AudioRecord.READ_BLOCKING);
            return Math.max(read, 0);
        } catch (Exception e) {
            return 0;
        }
    }

    private void mixPcm16(byte[] a, int aLen, byte[] b, int bLen, byte[] out, int outLen) {
        for (int i = 0; i < outLen; i += 2) {
            short sa = i + 1 < aLen ? (short) ((a[i] & 0xFF) | (a[i + 1] << 8)) : 0;
            short sb = i + 1 < bLen ? (short) ((b[i] & 0xFF) | (b[i + 1] << 8)) : 0;
            int mixed = sa + sb;
            if (mixed > Short.MAX_VALUE) mixed = Short.MAX_VALUE;
            if (mixed < Short.MIN_VALUE) mixed = Short.MIN_VALUE;
            out[i] = (byte) (mixed & 0xFF);
            out[i + 1] = (byte) ((mixed >> 8) & 0xFF);
        }
    }

    private long nextAudioPtsUs(int byteCount) {
        long durationUs = byteCount * 1_000_000L / (AUDIO_SAMPLE_RATE * AUDIO_CHANNELS * AUDIO_BYTES_PER_SAMPLE);
        long candidate = System.nanoTime() / 1000L - durationUs;
        if (lastAudioPtsUs >= 0 && candidate <= lastAudioPtsUs) candidate = lastAudioPtsUs + durationUs;
        lastAudioPtsUs = candidate;
        return candidate;
    }

    private void drain(MediaCodec codec, boolean isVideo) {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        try {
            while (running) {
                int index = codec.dequeueOutputBuffer(info, 10_000);
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (isVideo) ring.setVideoFormat(codec.getOutputFormat());
                    else ring.setAudioFormat(codec.getOutputFormat());
                } else if (index >= 0) {
                    ByteBuffer encoded = codec.getOutputBuffer(index);
                    if (encoded != null && info.size > 0 &&
                            (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        byte[] data = new byte[info.size];
                        encoded.position(info.offset);
                        encoded.limit(info.offset + info.size);
                        encoded.get(data);
                        ReplayBuffer.EncodedSample sample = new ReplayBuffer.EncodedSample(
                                data, info.presentationTimeUs, info.flags);
                        if (isVideo) ring.appendVideo(sample);
                        else ring.appendAudio(sample);
                    }
                    codec.releaseOutputBuffer(index, false);
                }
            }
        } catch (Exception error) {
            ring.reportFailure(error);
            Log.e("ReplayV8", "Recording buffer stopped", error);
        }
    }

    void saveLast(int seconds, SaveListener listener) {
        if (!running) { listener.done(false, "Tampon durduruldu."); return; }
        String failure = ring.getFailure();
        if (failure != null) { listener.done(false, "Tampon hatasi: " + failure); return; }
        if (!saving.compareAndSet(false, true)) {
            listener.done(false, "Bir klip zaten kaydediliyor."); return;
        }
        final ReplayBuffer.Snapshot snapshot = ring.snapshot(seconds);
        if (snapshot == null || snapshot.video.size() < 3) {
            saving.set(false);
            listener.done(false, "Secilen surenin tamami henuz tamponda yok. Biraz daha bekle.");
            return;
        }
        new Thread(() -> {
            try {
                String filename = muxToGallery(snapshot);
                listener.done(true, filename);
            } catch (Exception e) {
                listener.done(false, "Kaydetme hatası: " + e.getMessage());
            } finally {
                snapshot.close();
                saving.set(false);
            }
        }, "Replay-MP4Writer").start();
    }

    private String muxToGallery(ReplayBuffer.Snapshot snapshot) throws Exception {
        String filename = "Replay_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                .format(new Date()) + ".mp4";
        ContentResolver resolver = app.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ReplayGeriye");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri item = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (item == null) throw new Exception("MediaStore kaydı açılamadı");
        boolean success = false;
        try (ParcelFileDescriptor fd = resolver.openFileDescriptor(item, "w")) {
            if (fd == null) throw new Exception("Video dosyası açılamadı");
            MediaMuxer muxer = new MediaMuxer(fd.getFileDescriptor(),
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            try {
                int videoTrack = muxer.addTrack(snapshot.videoFormat);
                int audioTrack = snapshot.audioFormat == null ? -1 : muxer.addTrack(snapshot.audioFormat);
                muxer.start();
                int vi = 0, ai = 0;
                RandomAccessFile input = null;
                ReplayBuffer.FileSegment activeReadSegment = null;
                byte[] videoBytes = new byte[512 * 1024];
                try {
                    while (vi < snapshot.video.size() ||
                            (audioTrack >= 0 && ai < snapshot.audio.size())) {
                        boolean writeVideo;
                        if (vi >= snapshot.video.size()) writeVideo = false;
                        else if (audioTrack < 0 || ai >= snapshot.audio.size()) writeVideo = true;
                        else writeVideo = snapshot.video.get(vi).ptsUs <= snapshot.audio.get(ai).ptsUs;

                        ReplayBuffer.EncodedSample sample = writeVideo
                                ? snapshot.video.get(vi++) : snapshot.audio.get(ai++);
                        ByteBuffer encodedBytes;
                        if (writeVideo) {
                            if (activeReadSegment != sample.segment) {
                                if (input != null) input.close();
                                input = new RandomAccessFile(sample.segment.file, "r");
                                activeReadSegment = sample.segment;
                            }
                            if (videoBytes.length < sample.size) videoBytes = new byte[sample.size];
                            input.seek(sample.offset);
                            input.readFully(videoBytes, 0, sample.size);
                            encodedBytes = ByteBuffer.wrap(videoBytes, 0, sample.size);
                        } else {
                            encodedBytes = ByteBuffer.wrap(sample.data);
                        }
                        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                        info.set(0, sample.size,
                                Math.max(0, sample.ptsUs - snapshot.basePtsUs),
                                sample.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME);
                        muxer.writeSampleData(writeVideo ? videoTrack : audioTrack,
                                encodedBytes, info);
                    }
                } finally {
                    if (input != null) input.close();
                }
                muxer.stop();
                success = true;
            } finally { muxer.release(); }
        } finally {
            if (success) {
                ContentValues done = new ContentValues(); done.put(MediaStore.Video.Media.IS_PENDING, 0);
                resolver.update(item, done, null, null);
            } else resolver.delete(item, null, null);
        }
        return filename;
    }

    void stop() {
        running = false;
        stopRecord(playbackRecord);
        stopRecord(micRecord);
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (Exception ignored) { }
            virtualDisplay = null;
        }
        join(videoDrainThread); join(audioFeedThread); join(audioDrainThread);
        releaseAudioOnly();
        if (videoEncoder != null) {
            try { videoEncoder.stop(); } catch (Exception ignored) { }
            try { videoEncoder.release(); } catch (Exception ignored) { }
            videoEncoder = null;
        }
        if (inputSurface != null) { inputSurface.release(); inputSurface = null; }
        ring.close();
    }

    private void stopRecord(AudioRecord record) {
        if (record != null) {
            try { record.stop(); } catch (Exception ignored) { }
        }
    }

    private void releaseAudioOnly() {
        if (audioEncoder != null) {
            try { audioEncoder.stop(); } catch (Exception ignored) { }
            try { audioEncoder.release(); } catch (Exception ignored) { }
            audioEncoder = null;
        }
        if (playbackRecord != null) {
            try { playbackRecord.release(); } catch (Exception ignored) { }
            playbackRecord = null;
        }
        if (micRecord != null) {
            try { micRecord.release(); } catch (Exception ignored) { }
            micRecord = null;
        }
    }

    private void join(Thread thread) {
        if (thread != null && Thread.currentThread() != thread)
            try { thread.join(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
