package com.example.replaygeri;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;
import android.widget.Toast;

public class ReplayService extends Service {
    public static final String ACTION_START = "com.example.replaygeri.START";
    public static final String ACTION_SAVE = "com.example.replaygeri.SAVE";
    public static final String ACTION_STOP = "com.example.replaygeri.STOP";
    public static final String ACTION_OVERLAY = "com.example.replaygeri.OVERLAY";
    private static final int NOTIFICATION_ID = 427;
    private static final String CHANNEL = "replay_running";
    public static volatile boolean active = false;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private ReplayCapture capture;
    private MediaProjection projection;
    private boolean stopping;
    private WindowManager windowManager;
    private TextView overlay;
    private float angle;
    private Runnable spinTask;
    private ObjectAnimator overlayAnimator;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Geriye dönük kayıt",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Ekran yakalamanın açık olduğunu gösterir.");
        manager.createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        switch (intent.getAction()) {
            case ACTION_START:
                if (!active && capture == null) startCapture(intent);
                break;
            case ACTION_SAVE:
                if (!active || capture == null) toast("Önce tampon kaydı başlat.");
                else {
                    int seconds = intent.getIntExtra("seconds", getSharedPreferences("settings", MODE_PRIVATE)
                            .getInt("duration", 30));
                    capture.saveLast(seconds, (ok, detail) -> toast(ok
                            ? "Galeriye kaydedildi: " + detail : detail));
                }
                break;
            case ACTION_OVERLAY:
                if (active) showOverlay();
                break;
            case ACTION_STOP:
                stopCapture();
                stopSelf();
                break;
        }
        return START_NOT_STICKY;
    }

    private void startCapture(Intent permission) {
        try {
            startForeground(NOTIFICATION_ID, notification());
            int resultCode = permission.getIntExtra("resultCode", 0);
            Intent data;
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                data = permission.getParcelableExtra("resultData", Intent.class);
            } else data = permission.getParcelableExtra("resultData");
            if (data == null || resultCode != android.app.Activity.RESULT_OK)
                throw new IllegalStateException("Ekran paylaşım izni alınmadı");
            MediaProjectionManager manager = (MediaProjectionManager)
                    getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, data);
            if (projection == null) throw new IllegalStateException("MediaProjection yok");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    ui.post(() -> { if (!stopping) { toast("Ekran yakalama Android tarafından durduruldu.");
                        stopCapture(); stopSelf(); } });
                }
            }, ui);
            SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
            capture = new ReplayCapture(this);
            capture.start(projection, prefs);
            active = true;
            showOverlay();
            toast("V8 aktif: " + prefs.getString("active_video", "Kodlayıcı hazır")
                    + ". Son " + prefs.getInt("duration", 30) + " saniye hazır olunca kaydedebilirsin.");
        } catch (Exception error) {
            toast("Kayıt açılamadı: " + error.getMessage());
            stopCapture();
            stopSelf();
        }
    }

    private Notification notification() {
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 10, open, flags);
        Intent save = new Intent(this, ReplayService.class).setAction(ACTION_SAVE);
        PendingIntent saveAction = PendingIntent.getService(this, 11, save, flags);
        Intent stop = new Intent(this, ReplayService.class).setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, 12, stop, flags);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_save)
                .setContentTitle("Replay tamponu açık")
                .setContentText("Son 15/30/60 saniyeyi kaydetmek için dokun")
                .setOngoing(true).setContentIntent(content)
                .addAction(new Notification.Action.Builder(null, "Klip kaydet", saveAction).build())
                .addAction(new Notification.Action.Builder(null, "Durdur", stopAction).build())
                .build();
    }

    private void showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            
TextView bubble = new TextView(this) {
    @Override
    protected void onDraw(android.graphics.Canvas c) {
        c.save();
        c.rotate(angle, getWidth()/2f, getHeight()/2f);
        super.onDraw(c);
        c.restore();
    }
};
            bubble.setText("↻");
            bubble.setTextSize(28);
            bubble.setTextColor(0xFFFFFFFF);
            bubble.setGravity(Gravity.CENTER);
            GradientDrawable background = new GradientDrawable();
            background.setShape(GradientDrawable.OVAL);
            background.setColor(0xFFD6122B);
            background.setStroke(3, 0xFFFF6B7D);
            bubble.setBackground(background);
            int size = (int) (58 * getResources().getDisplayMetrics().density);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(size, size,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.RIGHT;
            params.x = 16;
            params.y = (int) (260 * getResources().getDisplayMetrics().density);
            bubble.setOnTouchListener(new View.OnTouchListener() {
                float initialX, initialY, downRawX, downRawY;
                boolean moved;
                @Override public boolean onTouch(View view, MotionEvent event) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = params.x; initialY = params.y;
                            downRawX = event.getRawX(); downRawY = event.getRawY();
                            moved = false; return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getRawX() - downRawX;
                            float dy = event.getRawY() - downRawY;
                            if (Math.abs(dx) + Math.abs(dy) > 20) moved = true;
                            if (moved) {
                                params.x = (int) (initialX - dx);
                                params.y = (int) (initialY + dy);
                                try { windowManager.updateViewLayout(bubble, params); }
                                catch (Exception ignored) { }
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (!moved) {
        spinOnce(bubble);
        Intent save = new Intent(ReplayService.this, ReplayService.class);
                                save.setAction(ACTION_SAVE);
                                startService(save);
                            }
                            return true;
                        default: return true;
                    }
                }
            });
            windowManager.addView(bubble, params);
            overlay = bubble;
            overlayAnimator = ObjectAnimator.ofFloat(bubble, View.ROTATION, 0f, 360f);
            overlayAnimator.setInterpolator(new LinearInterpolator());
            overlayAnimator.setDuration(1100);
            overlayAnimator.setRepeatCount(ValueAnimator.INFINITE);
            // Rotation starts only on tap.
        } catch (Exception error) { toast("Üst düğme açılamadı: " + error.getMessage()); }
    }


private void spinOnce(TextView bubble) {
    if (spinTask != null)
        bubble.removeCallbacks(spinTask);
    long start = android.os.SystemClock.uptimeMillis();
    spinTask = new Runnable() {
        @Override
        public void run() {
            float t = Math.min(1f,
                (android.os.SystemClock.uptimeMillis() - start) / 1000f);
            angle = 360f * t;
            bubble.invalidate();
            if (t < 1f)
                bubble.postOnAnimation(this);
            else {
                angle = 0f;
                bubble.invalidate();
            }
        }
    };
    bubble.postOnAnimation(spinTask);
}

    private void removeOverlay() {
        if (overlayAnimator != null) {
            overlayAnimator.cancel();
            overlayAnimator = null;
        }
        if (overlay != null && windowManager != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) { }
            overlay = null;
        }
    }

    private void stopCapture() {
        if (stopping) return;
        stopping = true;
        active = false;
        removeOverlay();
        if (capture != null) {
            capture.stop();
            capture = null;
        }
        if (projection != null) {
            try { projection.stop(); } catch (Exception ignored) { }
            projection = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
    }

    private void toast(String message) { ui.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show()); }
    @Override public void onDestroy() { stopCapture(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
