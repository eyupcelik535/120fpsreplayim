# Replay V8 – Xiaomi Pad Mini

Bu paket `ReplayGeriyeDonuk_v2_Ses_Mikrofon_Overlay.zip` içindeki kaynak kod temel alınarak hazırlandı.

## Değişiklikler

- 720p / 1080p seçimi korundu; 1080p cihaz ekran oranında 16 piksel hizalanarak kaydedilir.
- 30 / 60 / 120 FPS seçenekleri.
- 6 / 12 / 20 / 40 / 50 / 75 / 100 Mbps seçenekleri.
- Uygun donanımsal kodlayıcılar arasında H.265 (HEVC), ardından H.264 (AVC) denemesi.
- Önce seçili FPS denenir; cihaz/codec kaldırmazsa düşük FPS'ye geçilebilir.
- Codec daha düşük maksimum bitrate bildirirse otomatik düşürülür. Aktif kodlayıcı/FPS/bitrate uygulama ekranında görünür.
- 1 GiB video tamponu / 70 saniye penceresi, uygulamanın özel **geçici disk cache** alanında döngüsel dosyalarla saklanır. RAM'de 1 GiB ayrılmaz.
- 60 saniye seçildiğinde tam süre dolmadan 38 saniyelik klip kaydedilmez; uygulama bekleme uyarısı verir.
- V5 tek tur dönen ok animasyonu ve V6 ikon resmi korunmuştur.
- 120 FPS veya 100 Mbps gerçek çıktısı cihaz ve Android encoder/MediaProjection davranışına bağlıdır. 60 saniye tam kare doğruluğu için cihaz testi gerekir.

## GitHub Actions ile derleme

1. GitHub deponun kökünde `ReplayGeriyeDonuk_v2_Ses_Mikrofon_Overlay.zip` bulunsun.
2. `Replay-V8-GitHub-Workflow.yml` dosyasını `.github/workflows/replay-v8.yml` yoluna ekle (eski V7 workflow'unu çalıştırma).
3. GitHub -> Actions -> `Replay V8...` -> `Run workflow`.
4. `Replay-V8-APK` artifact'inden `app-debug.apk` dosyasını indir.

Bu paket Android SDK/Gradle içeren GitHub runner'da **derlenmek üzere hazırlandı**; burada Android SDK olmadığı için APK derlemesi ve Xiaomi Pad Mini üzerinde 120 FPS/100 Mbps kaydı test edilmedi.

100 Mbps video 60 saniyede teorik yaklaşık 750 MB tüketir; 1 GiB tampon, MP4 çıktısı ve kayıtta eski segmentlerin kısa süre tutulması için telefonda geçici olarak 2 GB'dan fazla boş alan gerekebilir.
